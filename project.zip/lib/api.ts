// API Configuration
// Replace this with your actual API base URL
const API_BASE_URL = 'http://localhost:3001/api';

// Helper function for API calls
async function apiCall(endpoint: string, options: RequestInit = {}) {
  const token = localStorage.getItem('authToken');
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` }),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: 'An error occurred' }));
    throw new Error(error.message || 'API request failed');
  }

  return response.json();
}

// Authentication APIs
export const authAPI = {
  login: async (email: string, password: string, role: string) => {
    return apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password, role }),
    });
  },

  logout: async () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userRole');
    localStorage.removeItem('userName');
  },

  getCurrentUser: async () => {
    return apiCall('/auth/me');
  },
};

// Courses APIs
export const coursesAPI = {
  getAll: async () => {
    return apiCall('/courses');
  },

  getById: async (id: number) => {
    return apiCall(`/courses/${id}`);
  },

  create: async (courseData: any) => {
    return apiCall('/courses', {
      method: 'POST',
      body: JSON.stringify(courseData),
    });
  },

  update: async (id: number, courseData: any) => {
    return apiCall(`/courses/${id}`, {
      method: 'PUT',
      body: JSON.stringify(courseData),
    });
  },

  delete: async (id: number) => {
    return apiCall(`/courses/${id}`, {
      method: 'DELETE',
    });
  },
};

// Library APIs
export const libraryAPI = {
  getAll: async (category?: string, search?: string) => {
    const params = new URLSearchParams();
    if (category && category !== 'All') params.append('category', category);
    if (search) params.append('search', search);
    
    return apiCall(`/library?${params.toString()}`);
  },

  getById: async (id: number) => {
    return apiCall(`/library/${id}`);
  },

  upload: async (bookData: any) => {
    return apiCall('/library', {
      method: 'POST',
      body: JSON.stringify(bookData),
    });
  },
};

// Tasks APIs
export const tasksAPI = {
  getAll: async (status?: string) => {
    const params = status && status !== 'all' ? `?status=${status}` : '';
    return apiCall(`/tasks${params}`);
  },

  getById: async (id: number) => {
    return apiCall(`/tasks/${id}`);
  },

  create: async (taskData: any) => {
    return apiCall('/tasks', {
      method: 'POST',
      body: JSON.stringify(taskData),
    });
  },

  update: async (id: number, taskData: any) => {
    return apiCall(`/tasks/${id}`, {
      method: 'PUT',
      body: JSON.stringify(taskData),
    });
  },

  updateStatus: async (id: number, status: string) => {
    return apiCall(`/tasks/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  },
};

// Schedule APIs
export const scheduleAPI = {
  getByDay: async (day: string) => {
    return apiCall(`/schedule?day=${day}`);
  },

  getAll: async () => {
    return apiCall('/schedule');
  },

  create: async (scheduleData: any) => {
    return apiCall('/schedule', {
      method: 'POST',
      body: JSON.stringify(scheduleData),
    });
  },
};

// Disciplines APIs
export const disciplinesAPI = {
  getAll: async () => {
    return apiCall('/disciplines');
  },

  getById: async (id: number) => {
    return apiCall(`/disciplines/${id}`);
  },

  getStudentProgress: async (disciplineId: number) => {
    return apiCall(`/disciplines/${disciplineId}/progress`);
  },
};

// Students APIs (for teachers)
export const studentsAPI = {
  getAll: async () => {
    return apiCall('/students');
  },

  getById: async (id: number) => {
    return apiCall(`/students/${id}`);
  },

  create: async (studentData: any) => {
    return apiCall('/students', {
      method: 'POST',
      body: JSON.stringify(studentData),
    });
  },

  update: async (id: number, studentData: any) => {
    return apiCall(`/students/${id}`, {
      method: 'PUT',
      body: JSON.stringify(studentData),
    });
  },
};