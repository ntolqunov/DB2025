import { Calendar, Clock, AlertCircle, CheckCircle2, Circle } from 'lucide-react';
import { useState } from 'react';

interface Task {
  id: number;
  title: string;
  course: string;
  dueDate: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'in-progress' | 'completed';
  description: string;
  points: number;
}

const mockTasks: Task[] = [
  {
    id: 1,
    title: 'Data Structures Assignment #3',
    course: 'Computer Science',
    dueDate: '2025-11-28',
    priority: 'high',
    status: 'in-progress',
    description: 'Implement binary search tree with insert, delete, and search operations',
    points: 100
  },
  {
    id: 2,
    title: 'Calculus Problem Set Chapter 5',
    course: 'Mathematics',
    dueDate: '2025-11-29',
    priority: 'medium',
    status: 'pending',
    description: 'Complete problems 1-25 from the textbook',
    points: 50
  },
  {
    id: 3,
    title: 'Business Case Study Analysis',
    course: 'Business Management',
    dueDate: '2025-11-30',
    priority: 'high',
    status: 'pending',
    description: 'Analyze the Tesla case study and prepare a 10-page report',
    points: 150
  },
  {
    id: 4,
    title: 'Physics Lab Report',
    course: 'Physics',
    dueDate: '2025-12-01',
    priority: 'medium',
    status: 'in-progress',
    description: 'Document findings from thermodynamics experiment',
    points: 75
  },
  {
    id: 5,
    title: 'Literature Essay: Shakespeare',
    course: 'English Literature',
    dueDate: '2025-12-02',
    priority: 'low',
    status: 'pending',
    description: 'Write a 5-page essay analyzing Hamlet\'s character development',
    points: 100
  },
  {
    id: 6,
    title: 'Algorithm Quiz Preparation',
    course: 'Computer Science',
    dueDate: '2025-11-27',
    priority: 'high',
    status: 'completed',
    description: 'Review sorting algorithms and time complexity',
    points: 50
  }
];

interface TasksProps {
  userRole: 'student' | 'teacher' | 'assistant';
}

export function Tasks({ userRole }: TasksProps) {
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'in-progress' | 'completed'>('all');

  const filteredTasks = filterStatus === 'all' 
    ? mockTasks 
    : mockTasks.filter(task => task.status === filterStatus);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50 border-red-200';
      case 'medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low': return 'text-green-600 bg-green-50 border-green-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="text-green-500" size={20} />;
      case 'in-progress': return <Circle className="text-blue-500" size={20} />;
      default: return <Circle className="text-gray-400" size={20} />;
    }
  };

  const getDaysUntilDue = (dueDate: string) => {
    const today = new Date('2025-11-26');
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="mb-2">
          {userRole === 'student' ? 'My Tasks & Assignments' : 'Manage Tasks & Assignments'}
        </h1>
        <p className="text-gray-600">
          {userRole === 'student' 
            ? 'Track and manage your coursework' 
            : 'Create and manage student assignments'}
        </p>
      </div>

      {userRole === 'teacher' && (
        <button className="mb-6 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
          + Create New Assignment
        </button>
      )}

      {/* Filter Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        <button
          onClick={() => setFilterStatus('all')}
          className={`px-6 py-2 rounded-lg whitespace-nowrap transition-colors ${
            filterStatus === 'all'
              ? 'bg-purple-600 text-white'
              : 'bg-white border border-gray-300 hover:border-purple-600'
          }`}
        >
          All Tasks
        </button>
        <button
          onClick={() => setFilterStatus('pending')}
          className={`px-6 py-2 rounded-lg whitespace-nowrap transition-colors ${
            filterStatus === 'pending'
              ? 'bg-purple-600 text-white'
              : 'bg-white border border-gray-300 hover:border-purple-600'
          }`}
        >
          Pending
        </button>
        <button
          onClick={() => setFilterStatus('in-progress')}
          className={`px-6 py-2 rounded-lg whitespace-nowrap transition-colors ${
            filterStatus === 'in-progress'
              ? 'bg-purple-600 text-white'
              : 'bg-white border border-gray-300 hover:border-purple-600'
          }`}
        >
          In Progress
        </button>
        <button
          onClick={() => setFilterStatus('completed')}
          className={`px-6 py-2 rounded-lg whitespace-nowrap transition-colors ${
            filterStatus === 'completed'
              ? 'bg-purple-600 text-white'
              : 'bg-white border border-gray-300 hover:border-purple-600'
          }`}
        >
          Completed
        </button>
      </div>

      {/* Tasks List */}
      <div className="space-y-4 mb-8">
        {filteredTasks.map(task => {
          const daysUntilDue = getDaysUntilDue(task.dueDate);
          const isOverdue = daysUntilDue < 0;
          const isDueSoon = daysUntilDue >= 0 && daysUntilDue <= 2;

          return (
            <div 
              key={task.id} 
              className={`bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow ${
                task.status === 'completed' ? 'opacity-60' : ''
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="mt-1">
                  {getStatusIcon(task.status)}
                </div>

                <div className="flex-1">
                  <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                    <div>
                      <h3 className={task.status === 'completed' ? 'line-through' : ''}>
                        {task.title}
                      </h3>
                      <p className="text-sm text-gray-600 mt-1">{task.course}</p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-full text-xs border ${getPriorityColor(task.priority)}`}>
                        {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
                      </span>
                      <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs">
                        {task.points} pts
                      </span>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-4">{task.description}</p>

                  <div className="flex flex-wrap items-center gap-4 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar size={16} />
                      <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                    </div>
                    
                    {task.status !== 'completed' && (
                      <div className={`flex items-center gap-2 ${
                        isOverdue ? 'text-red-600' : isDueSoon ? 'text-yellow-600' : 'text-gray-600'
                      }`}>
                        {(isOverdue || isDueSoon) && <AlertCircle size={16} />}
                        <span>
                          {isOverdue 
                            ? `Overdue by ${Math.abs(daysUntilDue)} day${Math.abs(daysUntilDue) !== 1 ? 's' : ''}`
                            : isDueSoon
                            ? `Due in ${daysUntilDue} day${daysUntilDue !== 1 ? 's' : ''}`
                            : `${daysUntilDue} days remaining`
                          }
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  {task.status !== 'completed' && (
                    <>
                      <button className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors whitespace-nowrap">
                        {userRole === 'student' ? 'Start Work' : 'View Submissions'}
                      </button>
                      <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap">
                        Details
                      </button>
                    </>
                  )}
                  {task.status === 'completed' && (
                    <button className="px-4 py-2 bg-green-100 text-green-700 rounded-lg cursor-default">
                      Completed
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Statistics */}
      <div className="bg-white rounded-xl p-6 shadow-sm">
        <h2 className="mb-4">Task Overview</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <div className="text-2xl text-gray-700 mb-1">
              {mockTasks.length}
            </div>
            <div className="text-sm text-gray-600">Total Tasks</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl text-blue-600 mb-1">
              {mockTasks.filter(t => t.status === 'in-progress').length}
            </div>
            <div className="text-sm text-gray-600">In Progress</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl text-yellow-600 mb-1">
              {mockTasks.filter(t => t.status === 'pending').length}
            </div>
            <div className="text-sm text-gray-600">Pending</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl text-green-600 mb-1">
              {mockTasks.filter(t => t.status === 'completed').length}
            </div>
            <div className="text-sm text-gray-600">Completed</div>
          </div>
        </div>
      </div>
    </div>
  );
}