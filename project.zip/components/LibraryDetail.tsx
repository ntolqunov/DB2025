import { ArrowLeft, Download, Eye, Star, BookOpen, FileText, ThumbsUp, MessageCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface LibraryDetailProps {
  itemId: number;
  onBack: () => void;
  userRole: 'student' | 'teacher' | 'assistant';
}

const mockBookData = {
  title: 'Introduction to Algorithms',
  author: 'Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, Clifford Stein',
  category: 'Computer Science',
  pages: 1312,
  format: 'PDF',
  thumbnail: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=800',
  downloads: 1245,
  views: 3421,
  rating: 4.8,
  reviews: 156,
  publishYear: 2009,
  edition: '3rd Edition',
  isbn: '978-0262033848',
  description: 'This book provides a comprehensive introduction to the modern study of computer algorithms. It presents many algorithms and covers them in considerable depth, yet makes their design and analysis accessible to all levels of readers. The book is designed to be both versatile and complete, and can be used for self-study or as a textbook in a wide variety of courses.',
  tableOfContents: [
    { chapter: 1, title: 'The Role of Algorithms in Computing', pages: '1-16' },
    { chapter: 2, title: 'Getting Started', pages: '17-43' },
    { chapter: 3, title: 'Growth of Functions', pages: '44-68' },
    { chapter: 4, title: 'Divide-and-Conquer', pages: '69-132' },
    { chapter: 5, title: 'Probabilistic Analysis and Randomized Algorithms', pages: '133-156' },
    { chapter: 6, title: 'Heapsort', pages: '157-180' },
    { chapter: 7, title: 'Quicksort', pages: '181-202' },
    { chapter: 8, title: 'Sorting in Linear Time', pages: '203-226' }
  ],
  reviews_list: [
    {
      id: 1,
      user: 'Alex M.',
      rating: 5,
      date: '2025-11-15',
      comment: 'Excellent resource for understanding algorithms. Very comprehensive and well-written.'
    },
    {
      id: 2,
      user: 'Sarah K.',
      rating: 4,
      date: '2025-11-10',
      comment: 'Great book, but can be challenging for beginners. Highly recommended for intermediate learners.'
    },
    {
      id: 3,
      user: 'Michael T.',
      rating: 5,
      date: '2025-11-05',
      comment: 'The go-to reference for algorithms. Clear explanations and thorough coverage.'
    }
  ]
};

export function LibraryDetail({ itemId, onBack, userRole }: LibraryDetailProps) {
  const book = mockBookData;

  return (
    <div>
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft size={20} />
        <span>Back to Library</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Book Header */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="w-full md:w-48 h-64 bg-gradient-to-br from-amber-100 to-amber-50 rounded-lg overflow-hidden flex-shrink-0">
                <ImageWithFallback 
                  src={book.thumbnail}
                  alt={book.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1">
                <div className="text-xs text-amber-800 mb-2">{book.category}</div>
                <h1 className="mb-2">{book.title}</h1>
                <p className="text-gray-600 mb-4">{book.author}</p>

                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-1">
                    <Star size={18} className="fill-yellow-400 text-yellow-400" />
                    <span>{book.rating}</span>
                    <span className="text-sm text-gray-500">({book.reviews} reviews)</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                  <div>
                    <span className="text-gray-600">Pages:</span>
                    <span className="ml-2">{book.pages}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Format:</span>
                    <span className="ml-2">{book.format}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Edition:</span>
                    <span className="ml-2">{book.edition}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Year:</span>
                    <span className="ml-2">{book.publishYear}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-gray-600">ISBN:</span>
                    <span className="ml-2">{book.isbn}</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button className="flex-1 px-6 py-3 bg-amber-800 text-white rounded-lg hover:bg-amber-900 transition-colors flex items-center justify-center gap-2">
                    <Download size={20} />
                    Download
                  </button>
                  <button className="px-6 py-3 border border-amber-800 text-amber-800 rounded-lg hover:bg-amber-50 transition-colors flex items-center gap-2">
                    <Eye size={20} />
                    Preview
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="mb-4">About this Book</h2>
            <p className="text-gray-600 leading-relaxed">{book.description}</p>
          </div>

          {/* Table of Contents */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="mb-4">Table of Contents</h2>
            <div className="space-y-3">
              {book.tableOfContents.map((item) => (
                <div 
                  key={item.chapter}
                  className="flex items-start justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex gap-3">
                    <span className="text-cyan-600">Ch. {item.chapter}</span>
                    <span>{item.title}</span>
                  </div>
                  <span className="text-sm text-gray-500">{item.pages}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Reviews */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="mb-4">Student Reviews</h2>
            <div className="space-y-4">
              {book.reviews_list.map((review) => (
                <div key={review.id} className="border-b border-gray-200 last:border-0 pb-4 last:pb-0">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span>{review.user}</span>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i}
                              size={14} 
                              className={i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                            />
                          ))}
                        </div>
                      </div>
                      <div className="text-sm text-gray-500">{new Date(review.date).toLocaleDateString()}</div>
                    </div>
                  </div>
                  <p className="text-gray-600">{review.comment}</p>
                  <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                    <button className="flex items-center gap-1 hover:text-gray-700">
                      <ThumbsUp size={14} />
                      <span>Helpful</span>
                    </button>
                    <button className="flex items-center gap-1 hover:text-gray-700">
                      <MessageCircle size={14} />
                      <span>Reply</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button className="w-full mt-4 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              Write a Review
            </button>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Stats */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="mb-4">Statistics</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-gray-600">
                  <Download size={18} />
                  <span>Downloads</span>
                </div>
                <span>{book.downloads}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-gray-600">
                  <Eye size={18} />
                  <span>Views</span>
                </div>
                <span>{book.views}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-gray-600">
                  <FileText size={18} />
                  <span>Pages</span>
                </div>
                <span>{book.pages}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-gray-600">
                  <BookOpen size={18} />
                  <span>Format</span>
                </div>
                <span>{book.format}</span>
              </div>
            </div>
          </div>

          {/* Related Books */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="mb-4">Related Books</h3>
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex gap-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                  <div className="w-12 h-16 bg-gradient-to-br from-amber-100 to-amber-50 rounded flex-shrink-0"></div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm truncate">Algorithm Design Manual</div>
                    <div className="text-xs text-gray-500">Steven S. Skiena</div>
                    <div className="flex items-center gap-1 mt-1">
                      <Star size={12} className="fill-yellow-400 text-yellow-400" />
                      <span className="text-xs">4.6</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {userRole === 'teacher' && (
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="mb-4">Actions</h3>
              <div className="space-y-2">
                <button className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                  Upload New Book
                </button>
                <button className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                  Edit Details
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
