import { Clock, Users, BookOpen, Star, Play } from 'lucide-react';
import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CourseDetail } from './CourseDetail';

interface Course {
  id: number;
  title: string;
  instructor: string;
  duration: string;
  students: number;
  progress: number;
  rating: number;
  thumbnail: string;
  category: string;
}

const mockCourses: Course[] = [
  {
    id: 1,
    title: 'Introduction to Computer Science',
    instructor: 'Dr. Sarah Johnson',
    duration: '12 weeks',
    students: 245,
    progress: 65,
    rating: 4.8,
    thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400',
    category: 'Computer Science'
  },
  {
    id: 2,
    title: 'Advanced Mathematics',
    instructor: 'Prof. Michael Chen',
    duration: '10 weeks',
    students: 189,
    progress: 40,
    rating: 4.6,
    thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400',
    category: 'Mathematics'
  },
  {
    id: 3,
    title: 'Business Management Fundamentals',
    instructor: 'Dr. Emily Rodriguez',
    duration: '8 weeks',
    students: 312,
    progress: 85,
    rating: 4.9,
    thumbnail: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400',
    category: 'Business'
  },
  {
    id: 4,
    title: 'Data Structures and Algorithms',
    instructor: 'Dr. Ahmed Hassan',
    duration: '14 weeks',
    students: 198,
    progress: 20,
    rating: 4.7,
    thumbnail: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=400',
    category: 'Computer Science'
  },
  {
    id: 5,
    title: 'English Literature',
    instructor: 'Prof. Jane Williams',
    duration: '12 weeks',
    students: 156,
    progress: 55,
    rating: 4.5,
    thumbnail: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400',
    category: 'Literature'
  },
  {
    id: 6,
    title: 'Physics: Mechanics and Thermodynamics',
    instructor: 'Dr. Robert Lee',
    duration: '16 weeks',
    students: 203,
    progress: 30,
    rating: 4.8,
    thumbnail: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=400',
    category: 'Physics'
  }
];

interface CoursesProps {
  userRole: 'student' | 'teacher' | 'assistant';
}

export function Courses({ userRole }: CoursesProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCourseId, setSelectedCourseId] = useState<number | null>(null);
  const categories = ['All', 'Computer Science', 'Mathematics', 'Business', 'Literature', 'Physics'];

  if (selectedCourseId) {
    return (
      <CourseDetail 
        courseId={selectedCourseId} 
        onBack={() => setSelectedCourseId(null)}
        userRole={userRole}
      />
    );
  }

  const filteredCourses = selectedCategory === 'All' 
    ? mockCourses 
    : mockCourses.filter(course => course.category === selectedCategory);

  return (
    <div>
      <div className="mb-8">
        <h1 className="mb-2">
          {userRole === 'student' ? 'My Online Courses' : 'Manage Courses'}
        </h1>
        <p className="text-gray-600">
          {userRole === 'student' 
            ? 'Continue learning and achieve your goals' 
            : 'View and manage all courses'}
        </p>
      </div>

      {userRole === 'teacher' && (
        <button className="mb-6 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
          + Create New Course
        </button>
      )}

      {/* Category Filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
              selectedCategory === category
                ? 'bg-cyan-500 text-white'
                : 'bg-white border border-gray-300 hover:border-cyan-500'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map(course => (
          <div key={course.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
            <div className="relative h-48 bg-gray-200">
              <ImageWithFallback 
                src={course.thumbnail}
                alt={course.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full flex items-center gap-1">
                <Star size={16} className="fill-yellow-400 text-yellow-400" />
                <span>{course.rating}</span>
              </div>
              <button 
                onClick={() => setSelectedCourseId(course.id)}
                className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition-opacity"
              >
                <div className="bg-white rounded-full p-4">
                  <Play size={24} className="text-cyan-500" />
                </div>
              </button>
            </div>
            
            <div className="p-5">
              <div className="text-xs text-cyan-600 mb-2">{course.category}</div>
              <h3 className="mb-3">{course.title}</h3>
              
              <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                <BookOpen size={16} />
                <span>{course.instructor}</span>
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                <div className="flex items-center gap-1">
                  <Clock size={16} />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users size={16} />
                  <span>{course.students} students</span>
                </div>
              </div>

              {userRole === 'student' && (
                <div className="mb-2">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Progress</span>
                    <span className="text-cyan-600">{course.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-cyan-500 h-2 rounded-full transition-all"
                      style={{ width: `${course.progress}%` }}
                    ></div>
                  </div>
                </div>
              )}

              <button 
                onClick={() => setSelectedCourseId(course.id)}
                className="w-full mt-4 px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors"
              >
                {userRole === 'student' ? 'Continue Learning' : 'Manage Course'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}