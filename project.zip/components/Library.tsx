import { Book, Download, Eye, Search, BookOpen, FileText } from 'lucide-react';
import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { LibraryDetail } from './LibraryDetail';

interface LibraryItem {
  id: number;
  title: string;
  author: string;
  category: string;
  pages: number;
  format: string;
  thumbnail: string;
  downloads: number;
  views: number;
}

const mockLibrary: LibraryItem[] = [
  {
    id: 1,
    title: 'Introduction to Algorithms',
    author: 'Thomas H. Cormen',
    category: 'Computer Science',
    pages: 1312,
    format: 'PDF',
    thumbnail: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400',
    downloads: 1245,
    views: 3421
  },
  {
    id: 2,
    title: 'Calculus: Early Transcendentals',
    author: 'James Stewart',
    category: 'Mathematics',
    pages: 1368,
    format: 'PDF',
    thumbnail: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=400',
    downloads: 892,
    views: 2156
  },
  {
    id: 3,
    title: 'Principles of Economics',
    author: 'N. Gregory Mankiw',
    category: 'Business',
    pages: 888,
    format: 'PDF',
    thumbnail: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=400',
    downloads: 756,
    views: 1834
  },
  {
    id: 4,
    title: 'Physics for Scientists and Engineers',
    author: 'Raymond A. Serway',
    category: 'Physics',
    pages: 1344,
    format: 'PDF',
    thumbnail: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400',
    downloads: 634,
    views: 1567
  },
  {
    id: 5,
    title: 'The Norton Anthology of English Literature',
    author: 'M. H. Abrams',
    category: 'Literature',
    pages: 2736,
    format: 'PDF',
    thumbnail: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400',
    downloads: 423,
    views: 987
  },
  {
    id: 6,
    title: 'Data Structures and Algorithm Analysis',
    author: 'Mark Allen Weiss',
    category: 'Computer Science',
    pages: 576,
    format: 'PDF',
    thumbnail: 'https://images.unsplash.com/photo-1550399105-c4db5fb85c18?w=400',
    downloads: 912,
    views: 2345
  }
];

interface LibraryProps {
  userRole: 'student' | 'teacher' | 'assistant';
}

export function Library({ userRole }: LibraryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedItemId, setSelectedItemId] = useState<number | null>(null);
  
  const categories = ['All', 'Computer Science', 'Mathematics', 'Business', 'Physics', 'Literature'];

  if (selectedItemId) {
    return (
      <LibraryDetail 
        itemId={selectedItemId} 
        onBack={() => setSelectedItemId(null)}
        userRole={userRole}
      />
    );
  }

  const filteredLibrary = mockLibrary.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div>
      <div className="mb-8">
        <h1 className="mb-2">Digital Library</h1>
        <p className="text-gray-600">Access textbooks, research papers, and study materials</p>
      </div>

      {userRole === 'teacher' && (
        <button className="mb-6 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
          + Upload New Book
        </button>
      )}

      {/* Search Bar */}
      <div className="mb-6 relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
        <input
          type="text"
          placeholder="Search books, authors, or topics..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
        />
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
              selectedCategory === category
                ? 'bg-amber-800 text-white'
                : 'bg-white border border-gray-300 hover:border-amber-800'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Library Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {filteredLibrary.map(item => (
          <div key={item.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
            <div className="relative h-64 bg-gradient-to-br from-amber-100 to-amber-50">
              <ImageWithFallback 
                src={item.thumbnail}
                alt={item.title}
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="p-5">
              <div className="text-xs text-amber-800 mb-2">{item.category}</div>
              <h3 className="mb-2">{item.title}</h3>
              <p className="text-gray-600 mb-4">{item.author}</p>

              <div className="flex items-center gap-4 text-sm text-gray-600 mb-4">
                <div className="flex items-center gap-1">
                  <FileText size={16} />
                  <span>{item.pages} pages</span>
                </div>
                <div className="px-2 py-1 bg-gray-100 rounded">
                  {item.format}
                </div>
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                <div className="flex items-center gap-1">
                  <Download size={16} />
                  <span>{item.downloads}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye size={16} />
                  <span>{item.views}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => setSelectedItemId(item.id)}
                  className="flex-1 px-4 py-2 bg-amber-800 text-white rounded-lg hover:bg-amber-900 transition-colors flex items-center justify-center gap-2"
                >
                  View Details
                </button>
                <button className="px-4 py-2 border border-amber-800 text-amber-800 rounded-lg hover:bg-amber-50 transition-colors">
                  <Eye size={20} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Statistics */}
      <div className="bg-white rounded-xl p-6 shadow-sm">
        <h2 className="mb-4">Library Statistics</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-amber-50 rounded-lg">
            <BookOpen size={32} className="mx-auto mb-2 text-amber-800" />
            <div className="text-2xl text-amber-800 mb-1">2,456</div>
            <div className="text-sm text-gray-600">Total Books</div>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <FileText size={32} className="mx-auto mb-2 text-blue-600" />
            <div className="text-2xl text-blue-600 mb-1">1,234</div>
            <div className="text-sm text-gray-600">Research Papers</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <Download size={32} className="mx-auto mb-2 text-green-600" />
            <div className="text-2xl text-green-600 mb-1">45,678</div>
            <div className="text-sm text-gray-600">Total Downloads</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <Book size={32} className="mx-auto mb-2 text-purple-600" />
            <div className="text-2xl text-purple-600 mb-1">156</div>
            <div className="text-sm text-gray-600">New This Month</div>
          </div>
        </div>
      </div>
    </div>
  );
}