import { useState } from 'react';
import { GraduationCap, Users, UserCheck, BookOpen, Mail, Lock } from 'lucide-react';

interface LoginProps {
  onLogin: (role: 'student' | 'teacher' | 'assistant', name: string) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [selectedRole, setSelectedRole] = useState<'student' | 'teacher' | 'assistant' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedRole && email && password && name) {
      onLogin(selectedRole, name);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <BookOpen size={48} className="text-cyan-600" />
            <h1 className="text-cyan-600">E-Learning Management System</h1>
          </div>
          <p className="text-gray-600">Welcome back! Please select your role and login</p>
        </div>

        {!selectedRole ? (
          /* Role Selection */
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <button
              onClick={() => setSelectedRole('student')}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1 text-left group"
            >
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <GraduationCap size={32} className="text-white" />
              </div>
              <h2 className="mb-2 text-gray-900">Student</h2>
              <p className="text-gray-600">
                Access courses, assignments, schedule, and library resources
              </p>
            </button>

            <button
              onClick={() => setSelectedRole('teacher')}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1 text-left group"
            >
              <div className="bg-gradient-to-br from-purple-500 to-purple-600 w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Users size={32} className="text-white" />
              </div>
              <h2 className="mb-2 text-gray-900">Teacher</h2>
              <p className="text-gray-600">
                Manage courses, create assignments, grade students, and track progress
              </p>
            </button>

            <button
              onClick={() => setSelectedRole('assistant')}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1 text-left group"
            >
              <div className="bg-gradient-to-br from-green-500 to-green-600 w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <UserCheck size={32} className="text-white" />
              </div>
              <h2 className="mb-2 text-gray-900">Teacher Assistant</h2>
              <p className="text-gray-600">
                Support teachers, assist with grading, and help manage courses
              </p>
            </button>
          </div>
        ) : (
          /* Login Form */
          <div className="max-w-md mx-auto">
            <div className="bg-white rounded-2xl p-8 shadow-xl">
              <div className="text-center mb-6">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-xl mb-4 ${
                  selectedRole === 'student' ? 'bg-gradient-to-br from-blue-500 to-blue-600' :
                  selectedRole === 'teacher' ? 'bg-gradient-to-br from-purple-500 to-purple-600' :
                  'bg-gradient-to-br from-green-500 to-green-600'
                }`}>
                  {selectedRole === 'student' && <GraduationCap size={32} className="text-white" />}
                  {selectedRole === 'teacher' && <Users size={32} className="text-white" />}
                  {selectedRole === 'assistant' && <UserCheck size={32} className="text-white" />}
                </div>
                <h2 className="text-gray-900 mb-2">
                  {selectedRole === 'student' ? 'Student Login' :
                   selectedRole === 'teacher' ? 'Teacher Login' :
                   'Teacher Assistant Login'}
                </h2>
                <p className="text-gray-600 text-sm">Enter your credentials to continue</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-700 mb-2">Full Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your full name"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email"
                      className="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-700 mb-2">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter your password"
                      className="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      required
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" className="rounded" />
                    <span className="text-gray-600">Remember me</span>
                  </label>
                  <button type="button" className="text-cyan-600 hover:text-cyan-700">
                    Forgot password?
                  </button>
                </div>

                <button
                  type="submit"
                  className={`w-full py-3 rounded-lg text-white transition-colors ${
                    selectedRole === 'student' ? 'bg-blue-600 hover:bg-blue-700' :
                    selectedRole === 'teacher' ? 'bg-purple-600 hover:bg-purple-700' :
                    'bg-green-600 hover:bg-green-700'
                  }`}
                >
                  Login
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedRole(null)}
                  className="w-full py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Back to Role Selection
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
