import { BookOpen, GraduationCap, TrendingUp, Award } from 'lucide-react';
import { useState } from 'react';

interface Discipline {
  id: number;
  name: string;
  instructor: string;
  credits: number;
  currentGrade: number;
  attendance: number;
  assignments: {
    completed: number;
    total: number;
  };
  nextClass: string;
  color: string;
}

const mockDisciplines: Discipline[] = [
  {
    id: 1,
    name: 'Data Structures and Algorithms',
    instructor: 'Dr. Sarah Johnson',
    credits: 4,
    currentGrade: 88,
    attendance: 95,
    assignments: { completed: 8, total: 10 },
    nextClass: 'Monday, 09:00',
    color: 'blue'
  },
  {
    id: 2,
    name: 'Advanced Calculus II',
    instructor: 'Prof. Michael Chen',
    credits: 4,
    currentGrade: 92,
    attendance: 100,
    assignments: { completed: 12, total: 12 },
    nextClass: 'Monday, 11:00',
    color: 'purple'
  },
  {
    id: 3,
    name: 'Business Management',
    instructor: 'Dr. Emily Rodriguez',
    credits: 3,
    currentGrade: 85,
    attendance: 90,
    assignments: { completed: 6, total: 8 },
    nextClass: 'Tuesday, 09:00',
    color: 'green'
  },
  {
    id: 4,
    name: 'Physics: Thermodynamics',
    instructor: 'Dr. Robert Lee',
    credits: 4,
    currentGrade: 78,
    attendance: 88,
    assignments: { completed: 5, total: 9 },
    nextClass: 'Thursday, 09:00',
    color: 'orange'
  },
  {
    id: 5,
    name: 'English Literature',
    instructor: 'Prof. Jane Williams',
    credits: 3,
    currentGrade: 94,
    attendance: 98,
    assignments: { completed: 7, total: 7 },
    nextClass: 'Tuesday, 13:00',
    color: 'pink'
  }
];

interface DisciplinesProps {
  userRole: 'student' | 'teacher' | 'assistant';
}

export function Disciplines({ userRole }: DisciplinesProps) {
  const [selectedDiscipline, setSelectedDiscipline] = useState<Discipline | null>(null);

  const getGradeColor = (grade: number) => {
    if (grade >= 90) return 'text-green-600 bg-green-50';
    if (grade >= 80) return 'text-blue-600 bg-blue-50';
    if (grade >= 70) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  const getColorClasses = (color: string) => {
    const colors: { [key: string]: string } = {
      blue: 'from-blue-500 to-blue-600',
      purple: 'from-purple-500 to-purple-600',
      green: 'from-green-500 to-green-600',
      orange: 'from-orange-500 to-orange-600',
      pink: 'from-pink-500 to-pink-600'
    };
    return colors[color] || colors.blue;
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="mb-2">
          {userRole === 'student' ? 'My Disciplines' : 'Manage Disciplines'}
        </h1>
        <p className="text-gray-600">
          {userRole === 'student' 
            ? 'View your enrolled courses and academic progress' 
            : 'Manage courses and student enrollments'}
        </p>
      </div>

      {userRole === 'teacher' && (
        <button className="mb-6 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
          + Create New Discipline
        </button>
      )}

      {/* Disciplines Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {mockDisciplines.map(discipline => (
          <div 
            key={discipline.id} 
            className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden"
          >
            <div className={`bg-gradient-to-r ${getColorClasses(discipline.color)} p-6 text-white`}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-white mb-2">{discipline.name}</h3>
                  <p className="text-white/90 text-sm">{discipline.instructor}</p>
                </div>
                {userRole === 'student' && (
                  <div className={`px-4 py-2 rounded-lg ${getGradeColor(discipline.currentGrade)}`}>
                    <div className="text-2xl">{discipline.currentGrade}%</div>
                  </div>
                )}
              </div>
              
              <div className="flex items-center gap-4 text-sm text-white/90">
                <div className="flex items-center gap-2">
                  <GraduationCap size={16} />
                  <span>{discipline.credits} Credits</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen size={16} />
                  <span>Next: {discipline.nextClass}</span>
                </div>
              </div>
            </div>

            <div className="p-6">
              {userRole === 'student' && (
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Attendance</div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${discipline.attendance}%` }}
                        ></div>
                      </div>
                      <span className="text-sm">{discipline.attendance}%</span>
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Assignments</div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full"
                          style={{ width: `${(discipline.assignments.completed / discipline.assignments.total) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm">
                        {discipline.assignments.completed}/{discipline.assignments.total}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <button 
                  onClick={() => setSelectedDiscipline(discipline)}
                  className="flex-1 px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
                >
                  {userRole === 'student' ? 'View Details' : 'Manage'}
                </button>
                <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                  Materials
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Academic Overview */}
      {userRole === 'student' && (
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h2 className="mb-6">Academic Performance</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <TrendingUp size={32} className="mx-auto mb-2 text-blue-600" />
              <div className="text-2xl text-blue-600 mb-1">
                {(mockDisciplines.reduce((sum, d) => sum + d.currentGrade, 0) / mockDisciplines.length).toFixed(1)}%
              </div>
              <div className="text-sm text-gray-600">Average Grade</div>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <Award size={32} className="mx-auto mb-2 text-green-600" />
              <div className="text-2xl text-green-600 mb-1">
                {mockDisciplines.reduce((sum, d) => sum + d.credits, 0)}
              </div>
              <div className="text-sm text-gray-600">Total Credits</div>
            </div>
            
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <BookOpen size={32} className="mx-auto mb-2 text-purple-600" />
              <div className="text-2xl text-purple-600 mb-1">
                {mockDisciplines.length}
              </div>
              <div className="text-sm text-gray-600">Active Courses</div>
            </div>
            
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <GraduationCap size={32} className="mx-auto mb-2 text-yellow-600" />
              <div className="text-2xl text-yellow-600 mb-1">
                {(mockDisciplines.reduce((sum, d) => sum + d.attendance, 0) / mockDisciplines.length).toFixed(0)}%
              </div>
              <div className="text-sm text-gray-600">Avg. Attendance</div>
            </div>
          </div>

          {/* Grade Distribution */}
          <div className="mt-6">
            <h3 className="mb-4">Grade Distribution</h3>
            <div className="space-y-3">
              {mockDisciplines.map(discipline => (
                <div key={discipline.id} className="flex items-center gap-4">
                  <div className="w-48 text-sm text-gray-700 truncate">{discipline.name}</div>
                  <div className="flex-1 bg-gray-200 rounded-full h-3">
                    <div 
                      className={`h-3 rounded-full bg-gradient-to-r ${getColorClasses(discipline.color)}`}
                      style={{ width: `${discipline.currentGrade}%` }}
                    ></div>
                  </div>
                  <div className={`w-16 text-center px-3 py-1 rounded-full text-sm ${getGradeColor(discipline.currentGrade)}`}>
                    {discipline.currentGrade}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedDiscipline && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedDiscipline(null)}
        >
          <div 
            className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className={`bg-gradient-to-r ${getColorClasses(selectedDiscipline.color)} p-6 text-white`}>
              <h2 className="text-white mb-2">{selectedDiscipline.name}</h2>
              <p className="text-white/90">{selectedDiscipline.instructor}</p>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Current Grade</div>
                  <div className="text-2xl">{selectedDiscipline.currentGrade}%</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Credits</div>
                  <div className="text-2xl">{selectedDiscipline.credits}</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Attendance</div>
                  <div className="text-2xl">{selectedDiscipline.attendance}%</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600 mb-1">Assignments</div>
                  <div className="text-2xl">
                    {selectedDiscipline.assignments.completed}/{selectedDiscipline.assignments.total}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setSelectedDiscipline(null)}
                className="w-full px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}