import { ArrowLeft, Play, FileText, Users, Clock, Download, CheckCircle2, Lock } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface CourseDetailProps {
  courseId: number;
  onBack: () => void;
  userRole: 'student' | 'teacher' | 'assistant';
}

interface Lesson {
  id: number;
  title: string;
  duration: string;
  completed: boolean;
  locked: boolean;
  type: 'video' | 'reading' | 'quiz';
}

interface Module {
  id: number;
  title: string;
  lessons: Lesson[];
}

const mockCourseData = {
  title: 'Introduction to Computer Science',
  instructor: 'Dr. Sarah Johnson',
  description: 'This comprehensive course covers the fundamentals of computer science, including programming concepts, data structures, algorithms, and problem-solving techniques. Perfect for beginners and those looking to strengthen their foundation.',
  thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800',
  duration: '12 weeks',
  students: 245,
  rating: 4.8,
  progress: 65,
  modules: [
    {
      id: 1,
      title: 'Introduction to Programming',
      lessons: [
        { id: 1, title: 'What is Programming?', duration: '15 min', completed: true, locked: false, type: 'video' as const },
        { id: 2, title: 'Setting Up Your Environment', duration: '20 min', completed: true, locked: false, type: 'video' as const },
        { id: 3, title: 'Your First Program', duration: '25 min', completed: true, locked: false, type: 'video' as const },
        { id: 4, title: 'Quiz: Programming Basics', duration: '10 min', completed: false, locked: false, type: 'quiz' as const }
      ]
    },
    {
      id: 2,
      title: 'Variables and Data Types',
      lessons: [
        { id: 5, title: 'Understanding Variables', duration: '18 min', completed: false, locked: false, type: 'video' as const },
        { id: 6, title: 'Primitive Data Types', duration: '22 min', completed: false, locked: false, type: 'video' as const },
        { id: 7, title: 'Type Conversion', duration: '15 min', completed: false, locked: false, type: 'reading' as const },
        { id: 8, title: 'Practice Exercises', duration: '30 min', completed: false, locked: false, type: 'quiz' as const }
      ]
    },
    {
      id: 3,
      title: 'Control Flow',
      lessons: [
        { id: 9, title: 'Conditional Statements', duration: '20 min', completed: false, locked: true, type: 'video' as const },
        { id: 10, title: 'Loops and Iteration', duration: '25 min', completed: false, locked: true, type: 'video' as const },
        { id: 11, title: 'Switch Statements', duration: '15 min', completed: false, locked: true, type: 'reading' as const },
        { id: 12, title: 'Quiz: Control Flow', duration: '15 min', completed: false, locked: true, type: 'quiz' as const }
      ]
    }
  ],
  resources: [
    { id: 1, name: 'Course Syllabus.pdf', size: '245 KB' },
    { id: 2, name: 'Lecture Slides - Week 1.pdf', size: '1.2 MB' },
    { id: 3, name: 'Programming Exercises.pdf', size: '567 KB' },
    { id: 4, name: 'Reference Materials.pdf', size: '3.4 MB' }
  ]
};

export function CourseDetail({ courseId, onBack, userRole }: CourseDetailProps) {
  const course = mockCourseData;

  const getLessonIcon = (type: string) => {
    switch (type) {
      case 'video': return <Play size={16} />;
      case 'reading': return <FileText size={16} />;
      case 'quiz': return <CheckCircle2 size={16} />;
      default: return <Play size={16} />;
    }
  };

  return (
    <div>
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft size={20} />
        <span>Back to Courses</span>
      </button>

      {/* Course Header */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
        <div className="relative h-64 md:h-80 bg-gray-200">
          <ImageWithFallback 
            src={course.thumbnail}
            alt={course.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
            <h1 className="text-white mb-2">{course.title}</h1>
            <p className="text-white/90">{course.instructor}</p>
          </div>
        </div>

        <div className="p-6">
          <p className="text-gray-600 mb-6">{course.description}</p>

          <div className="flex flex-wrap gap-6 mb-6">
            <div className="flex items-center gap-2">
              <Clock size={20} className="text-gray-400" />
              <span>{course.duration}</span>
            </div>
            <div className="flex items-center gap-2">
              <Users size={20} className="text-gray-400" />
              <span>{course.students} students</span>
            </div>
          </div>

          {userRole === 'student' && (
            <div className="mb-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Your Progress</span>
                <span className="text-cyan-600">{course.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-cyan-500 h-3 rounded-full transition-all"
                  style={{ width: `${course.progress}%` }}
                ></div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Course Content */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="mb-6">Course Content</h2>

            <div className="space-y-4">
              {course.modules.map((module, moduleIndex) => (
                <div key={module.id} className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="bg-gray-50 p-4 border-b border-gray-200">
                    <h3>Module {moduleIndex + 1}: {module.title}</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      {module.lessons.length} lessons
                    </p>
                  </div>

                  <div className="divide-y divide-gray-200">
                    {module.lessons.map((lesson) => (
                      <div 
                        key={lesson.id} 
                        className={`p-4 flex items-center justify-between hover:bg-gray-50 transition-colors ${
                          lesson.locked ? 'opacity-50' : 'cursor-pointer'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          {lesson.completed ? (
                            <CheckCircle2 size={20} className="text-green-500" />
                          ) : lesson.locked ? (
                            <Lock size={20} className="text-gray-400" />
                          ) : (
                            <div className="text-cyan-500">{getLessonIcon(lesson.type)}</div>
                          )}
                          <div>
                            <div className={lesson.completed ? 'line-through text-gray-500' : ''}>
                              {lesson.title}
                            </div>
                            <div className="text-sm text-gray-500">{lesson.duration}</div>
                          </div>
                        </div>

                        {!lesson.locked && (
                          <button className="px-4 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors">
                            {lesson.completed ? 'Review' : 'Start'}
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Resources */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="mb-4">Course Resources</h3>
            <div className="space-y-3">
              {course.resources.map((resource) => (
                <div 
                  key={resource.id}
                  className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <FileText size={20} className="text-gray-400" />
                    <div>
                      <div className="text-sm">{resource.name}</div>
                      <div className="text-xs text-gray-500">{resource.size}</div>
                    </div>
                  </div>
                  <button className="p-2 hover:bg-gray-100 rounded-lg">
                    <Download size={18} className="text-cyan-600" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Instructor Card */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="mb-4">Instructor</h3>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center text-white">
                {course.instructor.charAt(0)}
              </div>
              <div>
                <div>{course.instructor}</div>
                <div className="text-sm text-gray-600">Computer Science Professor</div>
              </div>
            </div>
            <button className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              Contact Instructor
            </button>
          </div>

          {userRole === 'teacher' && (
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="mb-4">Course Management</h3>
              <div className="space-y-2">
                <button className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                  Edit Course
                </button>
                <button className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                  View Analytics
                </button>
                <button className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                  Manage Students
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
