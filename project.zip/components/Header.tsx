import { Bell, MessageCircle, Mail, Menu, X, LogOut } from 'lucide-react';
import { useState } from 'react';

interface HeaderProps {
  currentView: string;
  onNavigate: (view: 'dashboard' | 'courses' | 'schedule' | 'library' | 'tasks' | 'disciplines') => void;
  userName: string;
  userRole: 'student' | 'teacher' | 'assistant';
  onLogout: () => void;
}

export function Header({ currentView, onNavigate, userName, userRole, onLogout }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getRoleBadgeColor = () => {
    switch (userRole) {
      case 'student': return 'bg-blue-100 text-blue-700';
      case 'teacher': return 'bg-purple-100 text-purple-700';
      case 'assistant': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getRoleLabel = () => {
    switch (userRole) {
      case 'student': return 'Student';
      case 'teacher': return 'Teacher';
      case 'assistant': return 'Teacher Assistant';
      default: return '';
    }
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Menu Toggle */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
            
            <h2 className="text-cyan-600">LMS</h2>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            <button
              onClick={() => onNavigate('dashboard')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === 'dashboard' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => onNavigate('courses')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === 'courses' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
              }`}
            >
              Courses
            </button>
            <button
              onClick={() => onNavigate('schedule')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === 'schedule' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
              }`}
            >
              Schedule
            </button>
            <button
              onClick={() => onNavigate('library')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === 'library' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
              }`}
            >
              Library
            </button>
            <button
              onClick={() => onNavigate('tasks')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentView === 'tasks' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
              }`}
            >
              Tasks
            </button>
          </nav>

          {/* User Actions */}
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-gray-100 rounded-lg relative">
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg">
              <MessageCircle size={20} />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg">
              <Mail size={20} />
            </button>
            
            <div className="flex items-center gap-3 ml-4">
              <div className="text-right hidden sm:block">
                <div className="text-sm">{userName}</div>
                <div className={`text-xs px-2 py-0.5 rounded-full ${getRoleBadgeColor()}`}>
                  {getRoleLabel()}
                </div>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center text-white">
                {userName.charAt(0).toUpperCase()}
              </div>
              <button
                onClick={onLogout}
                className="p-2 hover:bg-red-50 rounded-lg text-red-600"
                title="Logout"
              >
                <LogOut size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="lg:hidden py-4 border-t">
            <div className="flex flex-col gap-2">
              <button
                onClick={() => {
                  onNavigate('dashboard');
                  setMobileMenuOpen(false);
                }}
                className={`px-4 py-2 rounded-lg text-left transition-colors ${
                  currentView === 'dashboard' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => {
                  onNavigate('courses');
                  setMobileMenuOpen(false);
                }}
                className={`px-4 py-2 rounded-lg text-left transition-colors ${
                  currentView === 'courses' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
                }`}
              >
                Courses
              </button>
              <button
                onClick={() => {
                  onNavigate('schedule');
                  setMobileMenuOpen(false);
                }}
                className={`px-4 py-2 rounded-lg text-left transition-colors ${
                  currentView === 'schedule' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
                }`}
              >
                Schedule
              </button>
              <button
                onClick={() => {
                  onNavigate('library');
                  setMobileMenuOpen(false);
                }}
                className={`px-4 py-2 rounded-lg text-left transition-colors ${
                  currentView === 'library' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
                }`}
              >
                Library
              </button>
              <button
                onClick={() => {
                  onNavigate('tasks');
                  setMobileMenuOpen(false);
                }}
                className={`px-4 py-2 rounded-lg text-left transition-colors ${
                  currentView === 'tasks' ? 'bg-cyan-50 text-cyan-600' : 'hover:bg-gray-100'
                }`}
              >
                Tasks
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}