import { CheckSquare, BookOpen, Calendar, Megaphone, BookMarked, GraduationCap, ListTodo, FileText } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DashboardProps {
  onNavigate: (view: 'dashboard' | 'courses' | 'schedule' | 'library' | 'tasks' | 'disciplines') => void;
  userRole: 'student' | 'teacher' | 'assistant';
}

export function Dashboard({ onNavigate, userRole }: DashboardProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Testing and Control */}
      <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">
              {userRole === 'teacher' ? 'Create Tests' : 'Testing and Control'}
            </h2>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <CheckSquare size={20} className="text-white" />
                <span>A</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 border-2 border-white rounded"></div>
                <span>B</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 border-2 border-white rounded"></div>
                <span>C</span>
              </div>
            </div>
          </div>
          <button className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-blue-600 transition-colors">
            More
          </button>
        </div>
      </div>

      {/* Schedule */}
      <div className="bg-gradient-to-br from-cyan-400 to-cyan-500 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">Schedule</h2>
            <Calendar size={32} className="text-white/80" />
          </div>
          <button 
            onClick={() => onNavigate('schedule')}
            className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-cyan-500 transition-colors"
          >
            More
          </button>
        </div>
        <div className="absolute right-0 bottom-0 w-48 h-48 opacity-50">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1588453251771-cd919b362ed4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYWxlbmRhciUyMHNjaGVkdWxlJTIwcGxhbm5lcnxlbnwxfHx8fDE3NjQxMTQ3NTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Schedule"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* News */}
      <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">News</h2>
            <Megaphone size={32} className="text-white/80" />
          </div>
          <button className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-green-600 transition-colors">
            More
          </button>
        </div>
        <div className="absolute right-0 bottom-0 w-32 h-32 opacity-50">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1761759541793-4f8d0f6a9889?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWdhcGhvbmUlMjBhbm5vdW5jZW1lbnR8ZW58MXx8fHwxNzY0MTc2MzY0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="News"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Reference Book */}
      <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">Reference Book</h2>
            <BookMarked size={32} className="text-white/80" />
          </div>
          <button className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-orange-600 transition-colors">
            More
          </button>
        </div>
      </div>

      {/* Library */}
      <div className="bg-gradient-to-br from-amber-800 to-amber-900 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">Library</h2>
            <BookOpen size={32} className="text-white/80" />
          </div>
          <button 
            onClick={() => onNavigate('library')}
            className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-amber-900 transition-colors"
          >
            More
          </button>
        </div>
        <div className="absolute right-0 bottom-0 w-48 h-32 opacity-40">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1660479123634-2c700dfbbbdb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWJyYXJ5JTIwYm9va3MlMjBzdGFja3xlbnwxfHx8fDE3NjQxNzYzNjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Library"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* My Disciplines */}
      <div className="bg-gradient-to-br from-rose-500 to-rose-600 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">
              {userRole === 'student' ? 'My Disciplines' : 'Manage Courses'}
            </h2>
            <GraduationCap size={32} className="text-white/80" />
          </div>
          <button 
            onClick={() => onNavigate('disciplines')}
            className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-rose-600 transition-colors"
          >
            More
          </button>
        </div>
        <div className="absolute right-0 bottom-0 w-40 h-32 opacity-40">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1665791566577-a4f53c9b7185?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMG5vdGVib29rcyUyMGVkdWNhdGlvbnxlbnwxfHx8fDE3NjQxNzYzNjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Disciplines"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Online Courses */}
      <div className="bg-gradient-to-br from-amber-500 to-yellow-600 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">Online Courses</h2>
            <BookOpen size={32} className="text-white/80" />
          </div>
          <button 
            onClick={() => onNavigate('courses')}
            className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-amber-600 transition-colors"
          >
            More
          </button>
        </div>
        <div className="absolute right-0 bottom-0 w-48 h-32 opacity-40">
          <ImageWithFallback 
            src="https://images.unsplash.com/photo-1704748082614-8163a88e56b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwc3R1ZGVudHMlMjBzdHVkeWluZ3xlbnwxfHx8fDE3NjQxMTcwMDd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Online Courses"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Tasks */}
      <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">
              {userRole === 'student' ? 'Tasks' : 'Manage Tasks'}
            </h2>
            <ListTodo size={32} className="text-white/80" />
          </div>
          <button 
            onClick={() => onNavigate('tasks')}
            className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-purple-700 transition-colors"
          >
            More
          </button>
        </div>
        <div className="absolute right-0 bottom-0 w-48 h-32 opacity-40">
          <ImageWithFallback 
            src="https://images.unsplash.com/flagged/photo-1576697010739-6373b63f3204?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjBub3RlYm9vayUyMGRlc2t8ZW58MXx8fHwxNzY0MTc2MzY0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Tasks"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* My Requests */}
      <div className="bg-gradient-to-br from-lime-500 to-green-600 rounded-2xl p-6 text-white relative overflow-hidden min-h-[200px]">
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-4">
            <h2 className="text-2xl">My Requests</h2>
            <FileText size={32} className="text-white/80" />
          </div>
          <button className="px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-lime-600 transition-colors">
            More
          </button>
        </div>
      </div>
    </div>
  );
}
