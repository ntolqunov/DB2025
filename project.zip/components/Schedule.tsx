import { Calendar as CalendarIcon, Clock, MapPin, Video } from 'lucide-react';
import { useState } from 'react';

interface ScheduleEvent {
  id: number;
  title: string;
  instructor: string;
  time: string;
  duration: string;
  location: string;
  type: 'lecture' | 'lab' | 'online' | 'exam';
  day: string;
}

const mockSchedule: ScheduleEvent[] = [
  {
    id: 1,
    title: 'Computer Science - Data Structures',
    instructor: 'Dr. Sarah Johnson',
    time: '09:00',
    duration: '1h 30m',
    location: 'Room 301',
    type: 'lecture',
    day: 'Monday'
  },
  {
    id: 2,
    title: 'Mathematics - Calculus II',
    instructor: 'Prof. Michael Chen',
    time: '11:00',
    duration: '1h 30m',
    location: 'Room 205',
    type: 'lecture',
    day: 'Monday'
  },
  {
    id: 3,
    title: 'Physics Lab',
    instructor: 'Dr. Robert Lee',
    time: '14:00',
    duration: '2h',
    location: 'Lab Building A',
    type: 'lab',
    day: 'Monday'
  },
  {
    id: 4,
    title: 'Business Management',
    instructor: 'Dr. Emily Rodriguez',
    time: '09:00',
    duration: '1h 30m',
    location: 'Online',
    type: 'online',
    day: 'Tuesday'
  },
  {
    id: 5,
    title: 'English Literature',
    instructor: 'Prof. Jane Williams',
    time: '13:00',
    duration: '1h 30m',
    location: 'Room 102',
    type: 'lecture',
    day: 'Tuesday'
  },
  {
    id: 6,
    title: 'Computer Science Lab',
    instructor: 'Dr. Ahmed Hassan',
    time: '10:00',
    duration: '2h',
    location: 'Computer Lab 3',
    type: 'lab',
    day: 'Wednesday'
  },
  {
    id: 7,
    title: 'Mathematics - Midterm Exam',
    instructor: 'Prof. Michael Chen',
    time: '14:00',
    duration: '2h',
    location: 'Hall B',
    type: 'exam',
    day: 'Wednesday'
  },
  {
    id: 8,
    title: 'Physics - Thermodynamics',
    instructor: 'Dr. Robert Lee',
    time: '09:00',
    duration: '1h 30m',
    location: 'Room 401',
    type: 'lecture',
    day: 'Thursday'
  }
];

const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

interface ScheduleProps {
  userRole: 'student' | 'teacher' | 'assistant';
}

export function Schedule({ userRole }: ScheduleProps) {
  const [selectedDay, setSelectedDay] = useState<string>('Monday');

  const filteredSchedule = mockSchedule.filter(event => event.day === selectedDay);

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'lecture': return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'lab': return 'bg-purple-100 text-purple-700 border-purple-300';
      case 'online': return 'bg-green-100 text-green-700 border-green-300';
      case 'exam': return 'bg-red-100 text-red-700 border-red-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="mb-2">
          {userRole === 'student' ? 'My Schedule' : 'Manage Schedule'}
        </h1>
        <p className="text-gray-600">
          {userRole === 'student' 
            ? 'View your weekly class schedule' 
            : 'Manage class schedules and timetables'}
        </p>
      </div>

      {userRole === 'teacher' && (
        <button className="mb-6 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
          + Add New Class
        </button>
      )}

      {/* Day Selector */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {daysOfWeek.map(day => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            className={`px-6 py-3 rounded-lg whitespace-nowrap transition-colors ${
              selectedDay === day
                ? 'bg-cyan-500 text-white'
                : 'bg-white border border-gray-300 hover:border-cyan-500'
            }`}
          >
            {day}
          </button>
        ))}
      </div>

      {/* Schedule List */}
      <div className="space-y-4">
        {filteredSchedule.length > 0 ? (
          filteredSchedule.map(event => (
            <div 
              key={event.id} 
              className={`bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border-l-4 ${
                event.type === 'lecture' ? 'border-blue-500' :
                event.type === 'lab' ? 'border-purple-500' :
                event.type === 'online' ? 'border-green-500' :
                'border-red-500'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3>{event.title}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs border ${getTypeColor(event.type)}`}>
                      {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 mb-3">{event.instructor}</p>
                  
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <Clock size={16} />
                      <span>{event.time} ({event.duration})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {event.type === 'online' ? <Video size={16} /> : <MapPin size={16} />}
                      <span>{event.location}</span>
                    </div>
                  </div>
                </div>

                <button className="px-6 py-2 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors whitespace-nowrap">
                  {userRole === 'student' ? 'View Details' : 'Manage'}
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-xl p-12 text-center">
            <CalendarIcon size={48} className="mx-auto mb-4 text-gray-400" />
            <p className="text-gray-600">No classes scheduled for {selectedDay}</p>
          </div>
        )}
      </div>

      {/* Weekly Overview */}
      <div className="mt-8 bg-white rounded-xl p-6 shadow-sm">
        <h2 className="mb-4">Weekly Overview</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl text-blue-600 mb-1">12</div>
            <div className="text-sm text-gray-600">Total Classes</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl text-purple-600 mb-1">6</div>
            <div className="text-sm text-gray-600">Lab Sessions</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl text-green-600 mb-1">3</div>
            <div className="text-sm text-gray-600">Online Classes</div>
          </div>
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl text-red-600 mb-1">2</div>
            <div className="text-sm text-gray-600">Upcoming Exams</div>
          </div>
        </div>
      </div>
    </div>
  );
}